//
//  FBSession.h
//  VoterTest
//
//  Created by User User on 3/2/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FBConnect.h"

@interface FBSession : NSObject <FBRequestDelegate,FBDialogDelegate,FBSessionDelegate>
{
@private
    Facebook* facebook_;
    NSArray* permissions_;
    id delegate_;
}

@property(nonatomic, readonly) Facebook *facebook;
@property(nonatomic, retain)   NSArray *permissions;
@property(nonatomic, assign)   id delegate; 

- (id)initWithDelegate:(id) delegate; 

- (void)facebookLogin;
- (void)facebookLogout;
- (void)facebookGetInfo;


@end
