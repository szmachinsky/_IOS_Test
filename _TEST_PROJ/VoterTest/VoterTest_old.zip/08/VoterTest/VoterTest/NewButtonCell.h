//
//  NewButtonCell.h
//  VoterTest
//
//  Created by User on 2/20/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewButtonCell : UITableViewCell
{
    IBOutlet UIButton *cellButton_;
    
}

@property (nonatomic, retain) UIButton *cellButton;

//- (IBAction)pressButton:(id)sender;


@end
