//
//  SignUpViewController.h
//  VoterTest
//
//  Created by User on 2/16/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ScrollTextViewController.h"

@interface SignUpViewController :ScrollTextViewController <UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate> 
{
@private    
    IBOutlet UITableView *infoTableView_;
    
    IBOutlet UIButton *facebookButton_;    
    IBOutlet UIButton *twitterButton_;
    IBOutlet UIButton *googleButton_;
    IBOutlet UIButton *signUpButton_;

    NSString *username_;
    NSString *email_;      
    NSString *zipCode_;     
    NSString *yearOfBirth_; 
    NSString *password_;        
    
}

@property (nonatomic,copy) NSString *username;
@property (nonatomic,copy) NSString *email;      
@property (nonatomic,copy) NSString *zipCode;     
@property (nonatomic,copy) NSString *yearOfBirth; 
@property (nonatomic,copy) NSString *password;  


- (IBAction)pressFacebook:(id)sender;
- (IBAction)pressTwitter:(id)sender;
- (IBAction)pressGoogle:(id)sender;
- (IBAction)pressSignIn:(id)sender;

@end
